package br.com.isaiasbueno.dio.picpayclone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PicpaycloneApplication {

	public static void main(String[] args) {
		SpringApplication.run(PicpaycloneApplication.class, args);
	}

}
